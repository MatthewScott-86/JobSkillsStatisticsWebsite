'use strict';

$(document).ready(function(){
$('.btn-success').on('click', function(){
  console.log("loading");
  $('.loader').css("display", 'block');
  });
});
